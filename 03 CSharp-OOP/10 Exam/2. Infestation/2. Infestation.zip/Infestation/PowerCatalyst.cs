﻿namespace Infestation
{
    public class PowerCatalyst : Catalist
    {
        public PowerCatalyst()
            : base(PowerCatalystValue, 0, 0)
        {

        }
    }
}
