﻿namespace Infestation
{
    public class AggressionCatalyst : Catalist
    {
        public AggressionCatalyst()
            : base(0, 0, AggressionCatalystValue)
        {

        }
    }
}
