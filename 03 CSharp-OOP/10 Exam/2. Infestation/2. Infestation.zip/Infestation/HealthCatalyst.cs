﻿
namespace Infestation
{
    public class HealthCatalyst : Catalist
    {
        public HealthCatalyst()
            : base(0, HealthCatalystValue, 0)
        {

        }
    }
}
