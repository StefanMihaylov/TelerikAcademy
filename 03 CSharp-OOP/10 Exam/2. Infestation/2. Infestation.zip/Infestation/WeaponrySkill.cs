﻿namespace Infestation
{
    public class WeaponrySkill : Supplement
    {
        public WeaponrySkill()
            : base(0, 0, 0)
        {

        }

        public override void ReactTo(ISupplement otherSupplement)
        {

        }
    }
}
